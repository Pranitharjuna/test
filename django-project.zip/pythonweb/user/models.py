from django.db import models

class Article(models.Model):
	name = models.TextField(max_length=30)
	age = models.TextField(max_length=30)
class Meta:  
       db_table = "user"  
