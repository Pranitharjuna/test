#default
from django.shortcuts import render
# you should import 
from django.http import HttpResponse
from .models import Article

# Create your views here.
#def hello(request):
#	return HttpResponse("<h1>Welcome to Django</h1>")
def hello(request):
	articles = Article.objects.all()
	return render(request, 'login/login.html',{'articles':articles})	
	
def Contact(request):
	return HttpResponse("<h1>Contact Us</h1>")